package @portlet.action.name@.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class ViewAction extends DispatchAction{

	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request,HttpServletResponse response)throws Exception {
		
		return view(mapping, form, request, response);
	}
	
	public ActionForward view(ActionMapping mapping, ActionForm form, HttpServletRequest request,HttpServletResponse response)throws Exception {
			return mapping.findForward("portlet.@portlet.name@.view");	
	}
	
	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request,HttpServletResponse response)throws Exception {
		
		return mapping.findForward("portlet.@portlet.name@.view");
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request,HttpServletResponse response)throws Exception {
		
		return mapping.findForward("portlet.@portlet.name@.view");
	}
	
}
